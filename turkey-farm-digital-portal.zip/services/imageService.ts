
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export const generateBrandAsset = async (prompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            text: `Professional high-resolution vector-style farm logo. Circular emblem. 
            Title: 'Индюшки из Куликовки'. Subject: a friendly turkey, a large egg, farm barn in the background, oat stalks. 
            Style: eco-friendly, clean borders, warm browns, beige, forest green, yellow. 
            Symmetrical, no tiny details, suitable for stickers and packaging. White background. ${prompt}`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Image generation failed:", error);
    return null;
  }
};
