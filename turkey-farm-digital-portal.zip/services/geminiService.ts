
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export const getFarmAdvice = async (userPrompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: userPrompt,
      config: {
        systemInstruction: "Вы — Дмитрий, опытный фермер-птицевод из Ульяновской области (село Куликовка). Вы помогаете клиентам вашей фермы 'Индюшки из Куликовки' советами по выращиванию, кормлению и уходу за индейками. Ваш стиль общения: простой, доверительный, экспертный, доброжелательный. Вы используете понятные термины, избегаете лишней научности. Если спрашивают не про ферму или птиц, вежливо направьте разговор обратно к теме индюков.",
      },
    });
    return response.text || "Друг, что-то связь в Куликовке барахлит. Спроси еще разок!";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Произошла ошибка при связи с помощником фермера.";
  }
};

export const generateChecklist = async (experienceLevel: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Составь краткий чек-лист по выращиванию индейки для уровня: ${experienceLevel}. Включи пункты про подготовку брудера, кормление и важные нюансы. Формат: Маркированный список. Назови это 'Советы от Дмитрия'.`,
      config: {
        systemInstruction: "Вы фермер Дмитрий. Даете четкий и полезный список дел.",
      },
    });
    return response.text || "Не удалось сгенерировать чек-лист.";
  } catch (error) {
    return "Ошибка генерации чек-листа.";
  }
};
