
import React, { useState } from 'react';
import { generateBrandAsset } from '../services/imageService';

export const LogoGenerator: React.FC = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);

  const handleGenerate = async () => {
    setIsGenerating(true);
    const result = await generateBrandAsset("High quality sticker design, realistic textures, vibrant colors.");
    if (result) {
      setGeneratedImage(result);
    }
    setIsGenerating(false);
  };

  return (
    <div className="bg-white rounded-[3rem] p-10 shadow-2xl border-4 border-emerald-50">
      <div className="flex flex-col md:flex-row gap-10 items-center">
        <div className="flex-1">
          <h3 className="text-3xl font-black text-slate-900 mb-4">Генератор фирменных стикеров</h3>
          <p className="text-slate-500 mb-8 leading-relaxed">
            Создавайте уникальные наклейки для упаковки яиц и мяса. Нейросеть сгенерирует вариант логотипа специально для вашей печати.
          </p>
          <button 
            onClick={handleGenerate}
            disabled={isGenerating}
            className="bg-emerald-600 text-white px-10 py-5 rounded-2xl font-black text-lg hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-600/20 disabled:opacity-50 flex items-center gap-3"
          >
            {isGenerating ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                Рисуем логотип...
              </>
            ) : (
              '✨ Создать новую наклейку'
            )}
          </button>
        </div>
        
        <div className="w-64 h-64 bg-slate-50 rounded-[2.5rem] border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden relative group">
          {generatedImage ? (
            <>
              <img src={generatedImage} alt="Generated Logo" className="w-full h-full object-cover" />
              <a 
                href={generatedImage} 
                download="kulikovka-logo.png"
                className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white font-bold gap-2"
              >
                💾 Скачать
              </a>
            </>
          ) : (
            <div className="text-center p-6">
              <span className="text-4xl block mb-2 opacity-30">🎨</span>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Здесь появится ваш логотип</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
