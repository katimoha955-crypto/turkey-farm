
import React, { useState } from 'react';

const STEPS = [
  {
    title: "Этап 1: Инкубация",
    task: "Яйца заложены в инкубатор. На 25-й день влажность начала падать. Ваши действия?",
    options: [
      { text: "Срочно поднять влажность до 70-80%, опрыскав яйца теплой водой", points: 10, feedback: "Верно! Высокая влажность размягчает скорлупу, помогая индюшонку проклюнуться." },
      { text: "Ничего не менять, природа сама справится", points: 0, feedback: "Ошибка! Птенец может присохнуть к подскорлупной оболочке и погибнуть." },
      { text: "Открыть крышку для проветривания на час", points: -5, feedback: "Опасно! Резкое охлаждение на поздних сроках губительно." }
    ]
  },
  {
    title: "Этап 2: Первые сутки",
    task: "Индюшата вылупились. Какая температура должна быть в брудере прямо под лампой?",
    options: [
      { text: "Около +25...27 градусов", points: 0, feedback: "Холодно! Индюшата очень теплолюбивы и быстро простужаются." },
      { text: "Строго +35...37 градусов первые 3-5 дней", points: 10, feedback: "Идеально! Это имитирует тепло наседки и запускает метаболизм." },
      { text: "Чем жарче, тем лучше (+45 градусов)", points: -5, feedback: "Перегрев! Птица начнет задыхаться и терять влагу." }
    ]
  },
  {
    title: "Этап 3: Социализация",
    task: "Малыши начали забиваться в углы и «пирамидиться» (лезут друг на друга). Почему?",
    options: [
      { text: "Им просто весело играть", points: 0, feedback: "Нет, это инстинкт выживания, но опасный." },
      { text: "Им холодно или они напуганы ярким светом/шумом", points: 10, feedback: "Точно! Это сигнал тревоги. Нижние в пирамиде могут задохнуться." },
      { text: "Они ищут еду на полу", points: 0, feedback: "Обычно это связано с дискомфортом среды, а не с голодом." }
    ]
  },
  {
    title: "Этап 4: Подростки (1 месяц)",
    task: "Птица выросла. Пора ли выпускать их на траву, если на улице +18 и влажно?",
    options: [
      { text: "Да, свежий воздух полезен всегда", points: -10, feedback: "Очень рискованно! Сырость и сквозняк — главные враги индейки до 2 месяцев." },
      { text: "Нет, ждать сухого солнечного дня и прогретой земли", points: 10, feedback: "Верно! Только сухая погода и отсутствие росы безопасны для молодняка." },
      { text: "Выпустить на час и загнать обратно", points: 5, feedback: "Допустимо, но только если земля сухая." }
    ]
  },
  {
    title: "Этап 5: Финал - Рацион",
    task: "Для набора веса перед забоем решили добавить в рацион кукурузу. Как это повлияет?",
    options: [
      { text: "Мясо станет жестким", points: 0, feedback: "Напротив, кукуруза делает жир более мягким." },
      { text: "Кожа приобретет аппетитный желтоватый оттенок и жирок", points: 10, feedback: "Да! Это признак качественной домашней птицы." },
      { text: "Птица перестанет расти", points: -5, feedback: "Кукуруза — высокоэнергетичный корм, рост только ускорится." }
    ]
  }
];

export const GameMagnet: React.FC = () => {
  const [step, setStep] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [finished, setFinished] = useState(false);

  const handleChoice = (points: number, fb: string) => {
    setScore(prev => prev + points);
    setFeedback(fb);
    
    setTimeout(() => {
      if (step < STEPS.length - 1) {
        setStep(prev => prev + 1);
        setFeedback("");
      } else {
        setFinished(true);
      }
    }, 2500);
  };

  if (finished) {
    const isExpert = score >= 40;
    return (
      <div className="bg-emerald-900 text-white p-12 rounded-[3rem] text-center animate-in zoom-in duration-500">
        <h3 className="text-4xl font-black mb-6">Результат: {score} из 50 очков</h3>
        <p className="text-2xl mb-8">
          {isExpert ? "🏆 Вы — настоящий мастер-птицевод!" : "📈 У вас хороший потенциал, но есть нюансы."}
        </p>
        <p className="text-emerald-200 mb-10 text-lg leading-relaxed max-w-xl mx-auto">
          {isExpert 
            ? "Дмитрий оценит ваши знания! С такими навыками ваше стадо будет в полной безопасности." 
            : "Не переживайте! Главное — желание учиться. Дмитрий всегда подскажет правильный путь."}
        </p>
        <div className="bg-white/10 p-10 rounded-[2.5rem] border border-white/20">
          <p className="font-bold text-xl mb-6">🎁 Ваш бонус: «Секреты откормки от Дмитрия»</p>
          <button 
            onClick={() => document.getElementById('order')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-emerald-500 text-emerald-950 px-12 py-5 rounded-2xl font-black text-xl hover:bg-emerald-400 transition-all shadow-xl shadow-emerald-500/20 active:scale-95"
          >
            Получить материалы
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white p-12 rounded-[4rem] border-8 border-emerald-50 shadow-2xl relative overflow-hidden min-h-[600px] flex flex-col">
      <div className="relative z-10 flex-1 flex flex-col">
        <div className="flex justify-between items-center mb-10">
          <div>
            <div className="flex gap-1 mb-2">
              {STEPS.map((_, i) => (
                <div key={i} className={`h-1.5 w-8 rounded-full transition-all ${i <= step ? 'bg-emerald-500' : 'bg-slate-100'}`}></div>
              ))}
            </div>
            <h3 className="text-3xl font-black text-slate-900">{STEPS[step].title}</h3>
          </div>
          <div className="text-emerald-600 font-black text-xl">
             Счёт: {score}
          </div>
        </div>

        <p className="text-2xl font-bold text-slate-700 mb-12 leading-tight flex-1">{STEPS[step].task}</p>

        {feedback ? (
          <div className={`p-10 rounded-[2.5rem] text-xl font-bold animate-in slide-in-from-bottom-6 duration-300 ${feedback.includes("Верно") || feedback.includes("Идеально") || feedback.includes("Точно") ? "bg-emerald-100 text-emerald-800" : "bg-red-50 text-red-800"}`}>
             <div className="text-4xl mb-2">{feedback.includes("Верно") || feedback.includes("Идеально") || feedback.includes("Точно") ? "✅" : "⚠️"}</div>
            {feedback}
          </div>
        ) : (
          <div className="grid gap-4">
            {STEPS[step].options.map((opt, i) => (
              <button
                key={i}
                onClick={() => handleChoice(opt.points, opt.feedback)}
                className="w-full text-left p-6 rounded-[2rem] bg-slate-50 border-2 border-slate-100 hover:border-emerald-500 hover:bg-emerald-50 transition-all font-bold text-lg text-slate-700 shadow-sm flex items-center gap-4 group"
              >
                <div className="w-8 h-8 rounded-full border-2 border-slate-200 group-hover:border-emerald-500 flex items-center justify-center text-xs font-black">{i + 1}</div>
                {opt.text}
              </button>
            ))}
          </div>
        )}
      </div>
      
      {/* Decorative leaf */}
      <div className="absolute top-[-20px] right-[-20px] text-8xl opacity-5 select-none pointer-events-none">🌿</div>
    </div>
  );
};
