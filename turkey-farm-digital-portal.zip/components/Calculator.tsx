
import React, { useState, useEffect } from 'react';
import { PRODUCTS } from '../constants';

export const Calculator: React.FC = () => {
  const [selectedId, setSelectedId] = useState(PRODUCTS[0].id);
  const [quantity, setQuantity] = useState(1);
  const [total, setTotal] = useState(0);

  const product = PRODUCTS.find(p => p.id === selectedId);

  useEffect(() => {
    if (product) {
      const price = parseInt(product.price || '0');
      setTotal(price * quantity);
    }
  }, [selectedId, quantity, product]);

  return (
    <div className="bg-white p-4 md:p-12 rounded-[1.5rem] md:rounded-[3rem] shadow-xl border border-emerald-50 max-w-full overflow-hidden">
      <h3 className="text-lg md:text-3xl font-black text-slate-900 mb-5 md:mb-8 flex items-center gap-2">
        <span className="text-xl md:text-4xl">🧮</span> Расчет заказа
      </h3>
      
      <div className="space-y-5 md:space-y-8">
        <div>
          <label className="block text-[9px] md:text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-3">Выберите товар:</label>
          <div className="grid grid-cols-1 xs:grid-cols-2 gap-2">
            {PRODUCTS.map(p => (
              <button
                key={p.id}
                onClick={() => setSelectedId(p.id)}
                className={`text-left p-2.5 md:p-4 rounded-xl md:rounded-2xl border-2 transition-all ${
                  selectedId === p.id 
                    ? 'border-emerald-500 bg-emerald-50 shadow-sm' 
                    : 'border-slate-100 bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-lg md:text-2xl">{p.icon}</span>
                  <div className="min-w-0">
                    <div className="font-bold text-slate-800 text-[10px] md:text-sm leading-tight truncate">{p.title}</div>
                    <div className="text-[8px] md:text-[10px] text-slate-400 mt-0.5">{p.price} ₽/{p.unit}</div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-[9px] md:text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-2">Количество ({product?.unit}):</label>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
              className="w-10 h-10 md:w-16 md:h-16 bg-slate-100 rounded-lg md:rounded-2xl text-lg font-black shrink-0"
            >–</button>
            <input 
              type="number"
              min="1"
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 0))}
              className="flex-1 w-full min-w-0 h-10 md:h-16 text-center text-lg md:text-2xl font-black bg-white border-2 border-slate-100 rounded-lg md:rounded-2xl outline-none"
            />
            <button 
              onClick={() => setQuantity(prev => prev + 1)}
              className="w-10 h-10 md:w-16 md:h-16 bg-slate-100 rounded-lg md:rounded-2xl text-lg font-black shrink-0"
            >+</button>
          </div>
        </div>

        <div className="pt-4 md:pt-8 border-t border-slate-100">
          <div className="bg-emerald-900 rounded-xl md:rounded-[2rem] p-4 md:p-8 text-white">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
              <div className="text-center sm:text-left">
                <p className="text-emerald-300 text-[9px] font-bold uppercase tracking-widest mb-0.5">Итого:</p>
                <p className="text-2xl md:text-5xl font-black leading-none">
                  {total.toLocaleString()} <span className="text-lg md:text-2xl font-normal opacity-70">₽</span>
                </p>
              </div>
              <button 
                onClick={() => document.getElementById('order')?.scrollIntoView({ behavior: 'smooth' })}
                className="w-full sm:w-auto bg-white text-emerald-900 px-6 md:px-12 py-3 md:py-5 rounded-lg md:rounded-2xl font-black text-xs md:text-xl shadow-md active:scale-95 transition-transform"
              >
                Заказать
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
