
import React from 'react';

interface EmblemProps {
  className?: string;
  size?: number;
}

export const Emblem: React.FC<EmblemProps> = ({ className = "", size = 100 }) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 200 200" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={`${className} drop-shadow-md`}
    >
      <defs>
        <path id="textPath" d="M35,100 a65,65 0 1,1 130,0" />
        <linearGradient id="turkeyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{stopColor:'#8B4513'}} />
          <stop offset="100%" style={{stopColor:'#5D4037'}} />
        </linearGradient>
      </defs>

      {/* Основной фон круга */}
      <circle cx="100" cy="100" r="96" fill="white" stroke="#6B8E23" strokeWidth="4"/>
      <circle cx="100" cy="100" r="88" fill="none" stroke="#6B8E23" strokeWidth="1" strokeDasharray="2 2" opacity="0.5"/>

      {/* Колосья (упрощенно) */}
      <g stroke="#DAA520" fill="none" strokeWidth="1.5">
        <path d="M40,140 Q25,110 45,70" />
        <path d="M160,140 Q175,110 155,70" />
        {[75, 95, 115, 135].map(y => (
          <React.Fragment key={y}>
            <ellipse cx="32" cy={y} rx="4" ry="2" fill="#DAA520" transform={`rotate(-30, 32, ${y})`} />
            <ellipse cx="168" cy={y} rx="4" ry="2" fill="#DAA520" transform={`rotate(30, 168, ${y})`} />
          </React.Fragment>
        ))}
      </g>

      {/* Ферма (фон) */}
      <g transform="translate(55, 75) scale(0.6)">
        <path d="M0,60 L0,20 L40,0 L80,20 L80,60 Z" fill="#4F7942" stroke="#2D4F1E" strokeWidth="2"/>
        <path d="M0,20 L40,0 L80,20" fill="none" stroke="#B22222" strokeWidth="6"/>
        <rect x="25" y="30" width="30" height="30" fill="#3D2B1F" />
        <path d="M25,30 L55,60 M55,30 L25,60" stroke="#FDF8F1" strokeWidth="1"/>
      </g>

      {/* Текст по кругу */}
      <text fill="#6B8E23" fontSize="14" fontWeight="900" style={{ fontFamily: 'Arial, sans-serif' }}>
        <textPath href="#textPath" startOffset="50%" textAnchor="middle">
          ИНДЮШКИ ИЗ КУЛИКОВКИ
        </textPath>
      </text>

      {/* Индейка */}
      <g transform="translate(85, 80)">
        {/* Хвост веером */}
        <path d="M-15,40 Q15,-10 45,40" fill="#A0522D" stroke="#3D2B1F" strokeWidth="1"/>
        <path d="M-10,45 Q15,0 40,45" fill="#8B4513" stroke="#3D2B1F" strokeWidth="1"/>
        
        {/* Тело */}
        <ellipse cx="15" cy="55" rx="22" ry="18" fill="url(#turkeyGrad)" stroke="#3D2B1F" strokeWidth="1"/>
        
        {/* Шея и голова */}
        <path d="M30,50 Q45,50 45,30 Q45,15 35,15 C25,15 25,30 25,30" fill="#5D4037" stroke="#3D2B1F" strokeWidth="1"/>
        
        {/* Клюв и бородка */}
        <path d="M43,28 L50,30 L43,32 Z" fill="#FFD700"/>
        <path d="M45,32 Q48,40 44,42" stroke="#D32F2F" strokeWidth="3" strokeLinecap="round"/>
        
        {/* Глаз */}
        <circle cx="38" cy="25" r="1.5" fill="black"/>
        
        {/* Ноги */}
        <path d="M10,73 L8,85 M20,73 L22,85" stroke="#FFD700" strokeWidth="2" strokeLinecap="round"/>
      </g>

      {/* Яйцо (на переднем плане) */}
      <g transform="translate(55, 135)">
        <path 
          d="M20,0 C5,-5 -5,25 0,45 C5,60 35,60 40,45 C45,25 35,-5 20,0 Z" 
          fill="#FFFBF0" 
          stroke="#E5D3B3" 
          strokeWidth="1"
        />
        {/* Крапинки */}
        <circle cx="15" cy="15" r="1" fill="#D2B48C" opacity="0.6"/>
        <circle cx="25" cy="25" r="0.8" fill="#D2B48C" opacity="0.6"/>
        <circle cx="10" cy="35" r="1.2" fill="#D2B48C" opacity="0.6"/>
        <circle cx="30" cy="40" r="0.7" fill="#D2B48C" opacity="0.6"/>
      </g>
    </svg>
  );
};
