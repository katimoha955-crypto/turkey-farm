
import React, { useState } from 'react';

const QUESTIONS = [
  {
    id: 1,
    q: "Какова ваша главная цель?",
    options: [
      { text: "Вкусное мясо для семьи", next: 2 },
      { text: "Разведение птицы на даче", next: 2 },
      { text: "Свое дело/бизнес", next: 2 }
    ]
  },
  {
    id: 2,
    q: "Есть ли у вас опыт в птицеводстве?",
    options: [
      { text: "Я совсем новичок", next: 3 },
      { text: "Держал только кур", next: 3 },
      { text: "Уже выращивал индюков", next: 3 }
    ]
  },
  {
    id: 3,
    q: "Где планируете держать птицу?",
    options: [
      { text: "На дачном участке", next: 'result' },
      { text: "В частном доме (круглый год)", next: 'result' },
      { text: "На большой ферме", next: 'result' }
    ]
  }
];

export const Quiz: React.FC = () => {
  const [step, setStep] = useState(0);
  const [finished, setFinished] = useState(false);

  const handleAnswer = (next: number | string) => {
    if (next === 'result') setFinished(true);
    else setStep(prev => prev + 1);
  };

  if (finished) {
    return (
      <div className="bg-emerald-900 text-white p-8 md:p-12 rounded-[2rem] md:rounded-[3rem] text-center shadow-2xl">
        <div className="text-4xl md:text-6xl mb-6">🎉</div>
        <h3 className="text-xl md:text-3xl font-black mb-4 leading-tight">Индейка — отличный выбор!</h3>
        <p className="text-emerald-200 text-sm md:text-lg mb-8 md:mb-10 max-w-md mx-auto leading-relaxed">
          На основе ваших ответов, я рекомендую начать с **месячных индюшат** или готового мяса. 
        </p>
        <button 
          onClick={() => document.getElementById('order')?.scrollIntoView({ behavior: 'smooth' })}
          className="bg-emerald-400 text-emerald-950 px-8 md:px-12 py-4 md:py-5 rounded-xl md:rounded-2xl font-black text-lg md:text-xl hover:bg-emerald-300 transition-all shadow-xl active:scale-95"
        >
          Узнать подробнее
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 md:p-14 rounded-[2rem] md:rounded-[3rem] border-2 md:border-4 border-emerald-50 shadow-2xl relative overflow-hidden">
      <div className="relative z-10">
        <div className="flex justify-between items-center mb-6 md:mb-10">
          <h3 className="text-lg md:text-2xl font-black text-slate-900">Тест для вас</h3>
          <span className="bg-emerald-100 text-emerald-700 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest">
            {step + 1} / {QUESTIONS.length}
          </span>
        </div>
        
        <p className="text-xl md:text-2xl font-bold text-slate-700 mb-8 md:mb-10 leading-tight">
          {QUESTIONS[step].q}
        </p>
        
        <div className="grid gap-3 md:gap-4">
          {QUESTIONS[step].options.map((opt, i) => (
            <button
              key={i}
              onClick={() => handleAnswer(opt.next)}
              className="w-full text-left p-4 md:p-6 rounded-xl md:rounded-2xl bg-slate-50 border-2 border-slate-100 hover:border-emerald-500 hover:bg-emerald-50 transition-all font-bold text-sm md:text-lg text-slate-700 shadow-sm flex items-center gap-3 md:gap-4 group"
            >
              <div className="w-8 h-8 md:w-10 md:h-10 rounded-lg bg-white border-2 border-slate-200 group-hover:border-emerald-500 flex items-center justify-center text-xs font-black transition-colors shrink-0">
                {String.fromCharCode(65 + i)}
              </div>
              {opt.text}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
