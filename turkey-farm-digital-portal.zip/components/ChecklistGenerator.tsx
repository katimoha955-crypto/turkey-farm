
import React, { useState } from 'react';
import { generateChecklist } from '../services/geminiService';

export const ChecklistGenerator: React.FC = () => {
  const [level, setLevel] = useState('beginner');
  const [checklist, setChecklist] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    const result = await generateChecklist(level === 'beginner' ? 'Новичок' : 'Опытный птицевод');
    setChecklist(result);
    setLoading(false);
  };

  return (
    <div className="bg-emerald-50 p-8 rounded-3xl border-2 border-dashed border-emerald-200">
      <h2 className="text-2xl font-bold text-emerald-900 mb-4">Бесплатный чек-лист: «Как вырастить индейку без потерь»</h2>
      <p className="text-emerald-800 mb-6">Мы подготовим персональный план на основе вашего опыта. Выберите ваш уровень:</p>
      
      <div className="flex gap-4 mb-8">
        <button
          onClick={() => setLevel('beginner')}
          className={`flex-1 py-3 px-6 rounded-xl font-medium transition-all ${
            level === 'beginner' ? 'bg-emerald-600 text-white' : 'bg-white text-emerald-700 border border-emerald-200'
          }`}
        >
          Я только начинаю
        </button>
        <button
          onClick={() => setLevel('expert')}
          className={`flex-1 py-3 px-6 rounded-xl font-medium transition-all ${
            level === 'expert' ? 'bg-emerald-600 text-white' : 'bg-white text-emerald-700 border border-emerald-200'
          }`}
        >
          Уже есть опыт
        </button>
      </div>

      {!checklist ? (
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full bg-emerald-700 hover:bg-emerald-800 text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform transition-transform active:scale-95 disabled:opacity-70"
        >
          {loading ? 'Создаем ваш чек-лист...' : 'Получить чек-лист'}
        </button>
      ) : (
        <div className="bg-white p-6 rounded-2xl shadow-inner border border-emerald-100 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="prose prose-emerald max-w-none">
            <h4 className="text-emerald-900 font-bold mb-2">Ваш персональный план:</h4>
            <div className="whitespace-pre-wrap text-sm text-slate-700 leading-relaxed">
              {checklist}
            </div>
          </div>
          <button 
            onClick={() => setChecklist('')}
            className="mt-4 text-emerald-600 text-sm underline font-medium"
          >
            Сгенерировать заново
          </button>
        </div>
      )}
    </div>
  );
};
