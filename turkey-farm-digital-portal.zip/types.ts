
export interface Product {
  id: string;
  title: string;
  icon: string;
  description: string;
  price?: string;
  unit?: string;
  season?: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
}
